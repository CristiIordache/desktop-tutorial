import React, { useState, useEffect } from "react";
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Button, TextField, Dialog, DialogActions, DialogContent, DialogTitle } from "@mui/material";
import { useAuth } from "../contexts/authContext";
import { useNavigate } from "react-router-dom";
import Header from "./header";
import { db } from "../firebase";
import { collection, getDocs, doc, deleteDoc, getDoc, updateDoc } from "firebase/firestore";

function Home() {
    // Utilizăm `useNavigate` pentru a naviga între pagini
    const navigate = useNavigate();
    // Extragem utilizatorul curent din contextul de autentificare
    const { currentUser } = useAuth();
    // Starea pentru lista de utilizatori
    const [users, setUsers] = useState([]);
    // Starea pentru a verifica dacă utilizatorul curent este admin
    const [isAdmin, setIsAdmin] = useState(false);
    // Starea pentru utilizatorul care se editează în prezent
    const [editingUser, setEditingUser] = useState(null);
    // Starea pentru datele editate ale utilizatorului
    const [editedData, setEditedData] = useState({});

    // `useEffect` pentru a verifica autentificarea și încărcarea datelor utilizatorilor
    useEffect(() => {
        if (!currentUser) {
            // Dacă nu există un utilizator curent, navighează la pagina de login
            navigate('/login');
        } else {
            // Verifică dacă utilizatorul este admin și încarcă lista de utilizatori
            checkAdminStatus();
            fetchUsers();
        }
    }, [currentUser, navigate]);

    // Funcție pentru a prelua lista de utilizatori din Firestore
    const fetchUsers = async () => {
        const usersCollection = collection(db, "users");
        const usersSnapshot = await getDocs(usersCollection);
        const usersList = usersSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setUsers(usersList);
    };

    // Funcție pentru a verifica dacă utilizatorul curent este admin
    const checkAdminStatus = async () => {
        const userDoc = doc(db, "users", currentUser.uid);
        const userSnapshot = await getDoc(userDoc);
        const userData = userSnapshot.data();
        if (userData) {
            setIsAdmin(userData.isAdmin);
        }
    };

    // Funcție pentru a șterge un utilizator din Firestore
    const handleDelete = async (userId) => {
        await deleteDoc(doc(db, "users", userId));
        fetchUsers(); // Actualizează lista după ștergere
    };

    // Funcție pentru a inițializa editarea unui utilizator
    const handleEdit = (user) => {
        setEditingUser(user);
        setEditedData(user);
    };

    // Funcție pentru a actualiza starea datelor editate pe măsură ce utilizatorul modifică câmpurile
    const handleEditChange = (e) => {
        setEditedData({
            ...editedData,
            [e.target.name]: e.target.value,
        });
    };

    // Funcție pentru a trimite datele editate către Firestore
    const handleEditSubmit = async () => {
        const userDoc = doc(db, "users", editingUser.id);
        await updateDoc(userDoc, editedData);
        setEditingUser(null);
        fetchUsers(); // Actualizează lista după editare
    };

    // Funcție pentru a închide dialogul de editare
    const handleClose = () => {
        setEditingUser(null);
    };

    return (
        <div>
            <Header />
            <div>
                Hello {currentUser ? currentUser.email : "Placeholder"}
            </div>
            <TableContainer component={Paper} sx={{ marginTop: 10 }}>
                <Table aria-label="users table">
                    <TableHead>
                        <TableRow>
                            <TableCell>ID</TableCell>
                            <TableCell>Email</TableCell>
                            <TableCell>First Name</TableCell>
                            <TableCell>Last Name</TableCell>
                            <TableCell>Date of Birth</TableCell>
                            <TableCell>Password</TableCell>
                            {isAdmin && <TableCell>Actions</TableCell>}
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {users.map((user) => (
                            <TableRow key={user.id}>
                                <TableCell>{user.id}</TableCell>
                                <TableCell>{user.email}</TableCell>
                                <TableCell>{user.firstName}</TableCell>
                                <TableCell>{user.lastName}</TableCell>
                                <TableCell>{user.birthdate}</TableCell>
                                <TableCell>{user.password}</TableCell>
                                {isAdmin && (
                                    <TableCell>
                                        {!user.isAdmin && user.id !== currentUser.uid && (
                                            <Button
                                                variant="contained"
                                                color="secondary"
                                                onClick={() => handleDelete(user.id)}
                                            >
                                                Delete
                                            </Button>
                                        )}
                                        <Button
                                            variant="contained"
                                            color="primary"
                                            onClick={() => handleEdit(user)}
                                        >
                                            Edit
                                        </Button>
                                    </TableCell>
                                )}
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>

            <Dialog open={!!editingUser} onClose={handleClose}>
                <DialogTitle>Edit User</DialogTitle>
                <DialogContent>
                    <TextField
                        margin="dense"
                        name="email"
                        label="Email"
                        type="email"
                        fullWidth
                        value={editedData.email || ''}
                        onChange={handleEditChange}
                    />
                    <TextField
                        margin="dense"
                        name="firstName"
                        label="First Name"
                        type="text"
                        fullWidth
                        value={editedData.firstName || ''}
                        onChange={handleEditChange}
                    />
                    <TextField
                        margin="dense"
                        name="lastName"
                        label="Last Name"
                        type="text"
                        fullWidth
                        value={editedData.lastName || ''}
                        onChange={handleEditChange}
                    />
                    <TextField
                        margin="dense"
                        name="birthdate"
                        label="Date of Birth"
                        type="date"
                        fullWidth
                        value={editedData.birthdate || ''}
                        onChange={handleEditChange}
                        sx={{ 
                            height: '60px', // Set the height to 60px
                            '& .MuiInputBase-root': { // Target the input base
                                height: '130%', // Ensure the full height is utilized
                                padding: '15px', // Adjust the padding as necessary
                            },
                        }}
                    
                    />
                    <TextField
                        margin="dense"
                        name="password"
                        label="Password"
                        type="password"
                        fullWidth
                        value={editedData.password || ''}
                        onChange={handleEditChange}
                    />
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleClose} color="primary">
                        Cancel
                    </Button>
                    <Button onClick={handleEditSubmit} color="primary">
                        Save
                    </Button>
                </DialogActions>
            </Dialog>
        </div>
    );
}

export default Home;
