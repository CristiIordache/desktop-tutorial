function randomNumber() {
    
    var randomNum = Math.floor(Math.random() * 101);
  
    
    document.getElementById('num').innerText = randomNum;
  }