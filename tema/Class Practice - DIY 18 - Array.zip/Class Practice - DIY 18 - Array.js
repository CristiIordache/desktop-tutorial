//Write a script that initializes an array with the numbers 4,6,10.

//Print the array to the console.


 let array = [4, 6, 10]
console.log (array)
