var luckyNumber = parseInt(prompt("Enter your lucky number:"));


if (luckyNumber === 7) {
  alert("Congratulations! You've won 1,000,000$");
} else {
  alert("Try again next time!");
}