//Write a script that initializes a set with the numbers 1, 2, 3 and
//Print the set to the console.



let xset = new Set([1, 2, 3]);

console.log(xset);
