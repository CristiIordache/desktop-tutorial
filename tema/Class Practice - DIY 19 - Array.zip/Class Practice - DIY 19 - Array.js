//Write a script that initializes an array with the numbers 4,6,10.

//Print the reverse of array to the console.



let array = [4, 6, 10]

let reverseArray = array.slice().reverse()

console.log (reverseArray)
