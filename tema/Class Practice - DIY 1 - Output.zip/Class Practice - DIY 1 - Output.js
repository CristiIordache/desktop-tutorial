
// For practice complete the following exercises.
// 1.) Write a program that shows your name on the console.

// 2.) Write a program that shows your address on the console.

// 3.) Write a program that shows your name on alert.

// 4.) Write a program that shows your address on alert. java script


console.log("cristian Iordache ");

console.log("Enns");

alert("cristian Iordache");

alert("Enns");