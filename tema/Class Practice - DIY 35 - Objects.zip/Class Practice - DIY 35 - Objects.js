let computer = {
    price: 1200, 
    color: "silver",
    memory: "16GB"
};

console.log(computer);