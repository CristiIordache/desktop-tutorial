const displayMaxFromArray = (arr) => {
  if (arr.length === 0) {
    alert("The array is empty.");
  } else {
    alert("The maximum number is: " + maxNumber);
  }
};

const arr = [1, 6, 2, 9];

displayMaxFromArray(arr);
